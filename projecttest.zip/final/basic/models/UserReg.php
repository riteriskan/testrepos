<?php

namespace app\models;
use yii\db\ActiveRecord;
class UserReg extends ActiveRecord
{
    public static function tableName()
    {
        return 'inform';
    }
    public function rules(){
        return[
            [['login','password','name','surname'], 'required']
        ];
    }
}