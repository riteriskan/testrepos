<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\UserReg $model */
/** @var yii\widgets\ActiveForm $form */
/** @var app\models\Work $model1 */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="user-reg-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'login')->textInput(['maxlength' => false]) ?>

    <?= $form->field($model, 'password')->passwordInput(['maxlength' => false]) ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => false]) ?>

    <?= $form->field($model, 'surname')->textInput(['maxlength' => false]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

