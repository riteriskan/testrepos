<?php

use app\models\UserReg;
use app\models\Work;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/** @var yii\web\View $this */
/** @var app\models\UserRegSearch $userModel */
/** @var yii\data\ActiveDataProvider $userProvider */
/** @var app\models\WorkSearch $workModel */
/** @var yii\data\ActiveDataProvider $workProvider */

$this->title = 'User Regs';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-reg-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create User Reg', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $userProvider,
        'filterModel' => $userModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'login',
            'password',
            'name',
            'surname',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, UserReg $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                }
            ],
        ],
    ]); ?>
    <?= GridView::widget([
        'dataProvider' => $workProvider,
        'filterModel' => $workModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'uid',
            'PoW',
            'post',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, Work $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'uid' => $model->uid]);
                }
            ],
        ],
    ]); ?>




</div>


