<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\UserReg $model */
/** @var app\models\Work $model1 */
$this->title = 'Create User Reg';
$this->params['breadcrumbs'][] = ['label' => 'User Regs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-reg-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model
    ]) ?>

</div>
